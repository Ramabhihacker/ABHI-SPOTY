
let songs = [
    {title: "Song 1", src: "songs/song1.mp3", cover: "images/album1.jpg"},
    {title: "Song 2", src: "songs/song2.mp3", cover: "images/album2.jpg"},
];
let currentSong = 0;
const audio = document.getElementById('audio');
const title = document.getElementById('title');
const cover = document.getElementById('cover');
const playBtn = document.getElementById('play');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
function loadSong(songIndex){
    audio.src = songs[songIndex].src;
    title.textContent = songs[songIndex].title;
    cover.src = songs[songIndex].cover;
}
playBtn.addEventListener('click', () => {
    if(audio.paused){
        audio.play();
        playBtn.textContent = 'Pause';
    } else {
        audio.pause();
        playBtn.textContent = 'Play';
    }
});
prevBtn.addEventListener('click', () => {
    currentSong = (currentSong - 1 + songs.length) % songs.length;
    loadSong(currentSong);
    audio.play();
    playBtn.textContent = 'Pause';
});
nextBtn.addEventListener('click', () => {
    currentSong = (currentSong + 1) % songs.length;
    loadSong(currentSong);
    audio.play();
    playBtn.textContent = 'Pause';
});
loadSong(currentSong);
